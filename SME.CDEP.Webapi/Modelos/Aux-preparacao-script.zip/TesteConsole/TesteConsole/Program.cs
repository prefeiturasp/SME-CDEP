﻿using TesteConsole;
using TesteConsole.ArtesGrafica;
using TesteConsole.Audiovisual;
using TesteConsole.Bibliografico;
using TesteConsole.Documental;
using TesteConsole.Fotografico;

var arquivo = $@"C:\\Users\\vinicius.nyari\\OneDrive - AMcom\\CDEP\\acervos-liberacao\script_biliografico_{Guid.NewGuid()}_{DateTime.Now.ToString("HH_mm")}.sql";
var instrucaoSQL = Bibliografico.GerarScript();

// var arquivo = $@"C:\\Users\\vinicius.nyari\\OneDrive - AMcom\\CDEP\\acervos-liberacao\script_documental_{Guid.NewGuid()}_{DateTime.Now.ToString("HH_mm")}.sql";
// var instrucaoSQL = Documental.GerarScript();

// var arquivo = $@"C:\\Users\\vinicius.nyari\\OneDrive - AMcom\\CDEP\\acervos-liberacao\script_arte_grafica_{Guid.NewGuid()}_{DateTime.Now.ToString("HH_mm")}.sql";
// var instrucaoSQL = ArtesGrafica.GerarScript();

// var arquivo = $@"C:\\Users\\vinicius.nyari\\OneDrive - AMcom\\CDEP\\acervos-liberacao\script_audiovisual_{Guid.NewGuid()}_{DateTime.Now.ToString("HH_mm")}.sql";
// var instrucaoSQL = Audiovisual.GerarScript();

// var arquivo = $@"C:\\Users\\vinicius.nyari\\OneDrive - AMcom\\CDEP\\acervos-liberacao\script_fotografico_{Guid.NewGuid()}_{DateTime.Now.ToString("HH_mm")}.sql";
// var instrucaoSQL = Fotografico.GerarScript();

using (StreamWriter writer = new StreamWriter(arquivo))
     writer.Write(instrucaoSQL.ToString());

Console.WriteLine("Arquivo SQL gerado com sucesso.");

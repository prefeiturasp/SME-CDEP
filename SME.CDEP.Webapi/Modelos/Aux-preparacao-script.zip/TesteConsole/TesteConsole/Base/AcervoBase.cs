﻿using System.Text;

namespace TesteConsole.Base;

public static class AcervoBase
{
    private static StringBuilder scripts = new ();
    
    public static StringBuilder ObterScriptSimplesComNomeTipo(string[] valores, int tipo, string tabela)
    {
        var sql = new StringBuilder();
        sql.AppendLine("-----------------------------------------------");
        sql.AppendLine($"--> Script {tabela}");
        sql.AppendLine($"insert into {tabela} (nome, tipo) ");
        var contador = 1;
        var qtde = valores.Length;

        foreach (var valor in valores)
        {
            var valorTratado = RemoverAspasSimplesEDuplas(valor);
            sql.AppendLine($"select '{valorTratado}',{tipo} where not exists (select * from {tabela} where lower(nome) = lower('{valorTratado}') and tipo = {tipo}) ");
            if (contador != qtde)
                sql.AppendLine("union all ");
            contador++;
        }

        return sql;
    }
    
    public static StringBuilder ObterScriptSimplesComNome(string[] valores, string tabela)
    {
        var sql = new StringBuilder();
        sql.AppendLine("-----------------------------------------------");
        sql.AppendLine($"--> Script {tabela}");
        sql.AppendLine($"insert into {tabela} (nome) ");
        var contador = 1;
        var qtde = valores.Length;

        foreach (var valor in valores)
        {
            var valorTratado = RemoverAspasSimplesEDuplas(valor);
            sql.AppendLine($"select '{valorTratado}' where not exists (select * from {tabela} where lower(nome) = lower('{valorTratado}')) ");
            if (contador != qtde)
                sql.AppendLine("union all ");
            contador++;
        }

        return sql;
    }
    
    public static StringBuilder ObterScriptSimplesComNomeEAuditoria(string[] valores, string tabela)
    {
        var sql = new StringBuilder();
        sql.AppendLine("-----------------------------------------------");
        sql.AppendLine($"--> Script {tabela}");
        sql.AppendLine($"insert into {tabela} (nome, criado_em, criado_por, criado_login, excluido) ");
        var contador = 1;
        var qtde = valores.Length;

        foreach (var valor in valores)
        {
            var valorTratado = RemoverAspasSimplesEDuplas(valor);
            sql.AppendLine($"select '{valorTratado}', now(), 'Sistema', 'Sistema', false where not exists (select * from {tabela} where lower(nome) = lower('{valorTratado}')) ");
            if (contador != qtde)
                sql.AppendLine("union all ");
            contador++;
        }

        return sql;
    }

    public static StringBuilder ObterScriptCreditoAutoresCoAutoresEAuditoria(string[] valoresSeparadosPorPipes, int tipo, string titulo)
    {
        var sql = new StringBuilder();
        sql.AppendLine("-----------------------------------------------");
        sql.AppendLine($"--> Script {titulo}");
        
        sql.AppendLine("insert into credito_autor (nome, tipo, criado_em, criado_por, criado_login, excluido) ");

        var valoresTratados = valoresSeparadosPorPipes.SelectMany(s => s.Trim().Split("|")).Distinct();
        var qtdeLinha = valoresTratados.Count();
        var contador = 1;
        
        foreach (var valor in valoresTratados)
        {
            var valorTratado = RemoverAspasSimplesEDuplas(valor);
            sql.AppendLine($"select '{valorTratado}',{tipo}, now(), 'Sistema', 'Sistema', false where not exists (select * from credito_autor where lower(nome) = lower('{valorTratado}') and tipo = {tipo}) ");
            
            if (qtdeLinha != contador)
                sql.AppendLine("union all ");
            
            contador++;
        }
        
        return sql;
    }

    private static string RemoverAspasSimplesEDuplas(string valor)
    {
        return valor.Replace("\'","").Replace("\"","").Trim();
    }

    public static StringBuilder ObterScriptSeparadosPipesComNomeEAuditoria(string[] valoresSeparadosPorPipes, string tabela)
    {
        var sql = new StringBuilder();
        sql.AppendLine("-----------------------------------------------");
        sql.AppendLine($"--> Script {tabela}");
        
        sql.AppendLine($"insert into {tabela} (nome, criado_em, criado_por, criado_login, excluido) ");
        
        var valoresTratados = valoresSeparadosPorPipes.SelectMany(s => s.Trim().Split("|")).Distinct();
        var qtdeLinha = valoresTratados.Count();
        var contador = 1;
        
        foreach (var valor in valoresTratados)
        {

            // if (valor.Length >= 190)
            //     Console.WriteLine(valor);
            
            var valorTratado = RemoverAspasSimplesEDuplas(valor);
            sql.AppendLine($"select '{valorTratado}', now(), 'Sistema', 'Sistema', false where not exists (select * from {tabela} where lower(nome) = lower('{valorTratado}')) ");
            
            if (contador != qtdeLinha)
                sql.AppendLine("union all ");
            
            contador++;
        }
        
        return sql;
    }

    public static void Append(StringBuilder scripts)
    {
        AcervoBase.scripts.Append(scripts);
    }
    
    public static StringBuilder GerarScript()
    {
        return scripts;
    }
}
﻿namespace TesteConsole.ArtesGraficas;

public static class ArtesGraficaSuportes
{
    public static string[] Suportes()
    {
        return new[] { "PAPEL","DIGITAL","NEGATIVO" };
    }
}
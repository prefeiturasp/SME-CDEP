﻿using System.Text;
using TesteConsole.ArtesGraficas;
using TesteConsole.Base;

namespace TesteConsole.ArtesGrafica;

public static class ArtesGrafica
{
    public static StringBuilder Creditos()
    {
        return AcervoBase.ObterScriptCreditoAutoresCoAutoresEAuditoria(ArtesGraficaCreditos.Creditos(), 1, "Créditos");
    }
    
    public static StringBuilder Cromias()
    {
        return AcervoBase.ObterScriptSimplesComNome(ArtesGraficaCromias.Cromias(), "cromia");
    }
    
    public static StringBuilder Suportes()
    {
        return AcervoBase.ObterScriptSimplesComNomeTipo(ArtesGraficaSuportes.Suportes(), 1,"suporte");
    }

    public static StringBuilder GerarScript()
    {
        AcervoBase.Append(Creditos());
        AcervoBase.Append(Cromias());
        AcervoBase.Append(Suportes());
        return AcervoBase.GerarScript();
    }
}
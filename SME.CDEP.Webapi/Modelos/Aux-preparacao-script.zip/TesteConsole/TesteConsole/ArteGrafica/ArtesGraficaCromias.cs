﻿namespace TesteConsole.ArtesGraficas;

public static class ArtesGraficaCromias
{
    public static string[] Cromias()
    {
        return new[] { "COLOR","PB" };
    }
}
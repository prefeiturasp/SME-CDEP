﻿namespace TesteConsole.Documental;

public static class DocumentalConservacao
{
    public static string[] EstadoConservacoes()
    {
        return new[] { "BOM","REGULAR","ÓTIMO", "RUIM" };
    }
}
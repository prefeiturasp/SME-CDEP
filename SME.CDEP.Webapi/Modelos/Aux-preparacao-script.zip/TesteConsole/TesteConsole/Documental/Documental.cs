﻿using System.Text;
using TesteConsole.Base;

namespace TesteConsole.Documental;

public static class Documental
{
    public static StringBuilder Materiais()
    {
        return AcervoBase.ObterScriptSimplesComNomeTipo(new[] { "APOSTILA", "PERIÓDICO", "LIVRO" }, 1,"material");
    }
    
    public static StringBuilder Autores()
    {
        return AcervoBase.ObterScriptCreditoAutoresCoAutoresEAuditoria(DocumentalAutores.Autores(), 2, "Autores");
    }
    
    public static StringBuilder AcessoDocumentos()
    {
        return AcervoBase.ObterScriptSimplesComNome(DocumentalAcessoDocumentos.AcessoDocumentos(),"acesso_documento");
    }
    
    public static StringBuilder EstadoConservacoes()
    {
        return AcervoBase.ObterScriptSimplesComNome(DocumentalConservacao.EstadoConservacoes(), "conservacao");
    }

    public static StringBuilder GerarScript()
    {
        AcervoBase.Append(Materiais());
        AcervoBase.Append(Autores());
        AcervoBase.Append(AcessoDocumentos());
        AcervoBase.Append(EstadoConservacoes());
        return AcervoBase.GerarScript();
    }
    
    
}
﻿namespace TesteConsole.Documental;

public static class DocumentalAcessoDocumentos
{
    public static string[] AcessoDocumentos()
    {
        return new[] { "DIGITAL","ON-LINE","FÍSICO" };
    }
}
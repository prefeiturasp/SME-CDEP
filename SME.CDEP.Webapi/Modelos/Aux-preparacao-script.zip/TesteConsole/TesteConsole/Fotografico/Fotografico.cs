﻿using System.Text;
using TesteConsole.Base;

namespace TesteConsole.Fotografico;

public static class Fotografico
{
    public static StringBuilder Creditos()
    {
        return AcervoBase.ObterScriptCreditoAutoresCoAutoresEAuditoria(FotograficoCreditos.Creditos(), 1, "Créditos");
    }
    
    public static StringBuilder FormatoImagens()
    {
        return AcervoBase.ObterScriptSimplesComNomeTipo(FotograficoFormatosImagens.FormatosImagens(), 1,"formato");
    }
    

    public static StringBuilder GerarScript()
    {
        AcervoBase.Append(Creditos());
        AcervoBase.Append(FormatoImagens());
        return AcervoBase.GerarScript();
    }
}
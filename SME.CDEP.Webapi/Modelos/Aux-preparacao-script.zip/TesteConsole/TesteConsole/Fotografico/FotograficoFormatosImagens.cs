﻿namespace TesteConsole.Fotografico;

public static class FotograficoFormatosImagens
{
    public static string[] FormatosImagens()
    {
        return new[] { "JPEG","TIFF" };
    }
}
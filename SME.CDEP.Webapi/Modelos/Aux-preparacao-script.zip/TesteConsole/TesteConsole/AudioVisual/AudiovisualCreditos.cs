﻿namespace TesteConsole.Audiovisual;

public static class AudiovisualCreditos
{
    public static string[] Creditos()
    {
        return new[] { "NÚCLEO DE FOTO E VÍDEO EDUCAÇÃO"};
    }
}
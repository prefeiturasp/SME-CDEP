﻿using System.Text;
using TesteConsole.Base;

namespace TesteConsole.Audiovisual;

public static class Audiovisual
{
    public static StringBuilder Creditos()
    {
        return AcervoBase.ObterScriptCreditoAutoresCoAutoresEAuditoria(AudiovisualCreditos.Creditos(), 1, "Créditos");
    }
    
    public static StringBuilder Suportes()
    {
        return AcervoBase.ObterScriptSimplesComNomeTipo(AudiovisualSuportes.Suportes(), 2,"suporte");
    }

    public static StringBuilder GerarScript()
    {
        AcervoBase.Append(Creditos());
        AcervoBase.Append(Suportes());
        return AcervoBase.GerarScript();
    }
}
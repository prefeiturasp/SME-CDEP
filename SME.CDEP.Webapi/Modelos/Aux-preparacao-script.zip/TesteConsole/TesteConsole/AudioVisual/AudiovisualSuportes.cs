﻿namespace TesteConsole.Audiovisual;

public static class AudiovisualSuportes
{
    public static string[] Suportes()
    {
        return new[] { "VHS","DVD" };
    }
}
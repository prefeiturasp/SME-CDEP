﻿namespace TesteConsole.Audiovisual;

public static class AudiovisualCromias
{
    public static string[] Cromias()
    {
        return new[] { ""
        };
    }
}
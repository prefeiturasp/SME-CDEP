﻿using System.Text;
using TesteConsole.Base;

namespace TesteConsole.Bibliografico;

public static class Bibliografico
{
    public static StringBuilder Materiais()
    {
        return AcervoBase.ObterScriptSimplesComNomeTipo(new[] { "LIVRO","TESE","PERIÓDICO","LIVRETO","LIVRO" }, 2,"material");
    }
    
    public static StringBuilder Idiomas()
    {
        return AcervoBase.ObterScriptSimplesComNome(new[] { "PORTUGUÊS", "INGLÊS", "ESPANHOL", "FRANCÊS" },"idioma");
    }
    
    public static StringBuilder Autores()
    {
        return AcervoBase.ObterScriptCreditoAutoresCoAutoresEAuditoria(BibliograficoAutores.Autores(), 2, "Autores");
    }
    
    public static StringBuilder CoAutores()
    {
        return AcervoBase.ObterScriptCreditoAutoresCoAutoresEAuditoria(BibliograficoCoAutores.CoAutores(), 3, "CoAutores");
    }
    
    public static StringBuilder Editoras()
    {
        return AcervoBase.ObterScriptSimplesComNomeEAuditoria(BibliograficoEditoras.Editoras(), "Editora");
    }
    
    public static StringBuilder Assuntos()
    {
        return AcervoBase.ObterScriptSeparadosPipesComNomeEAuditoria(BibliograficoAssuntos.Assuntos(), "assunto");
    }
    
    public static StringBuilder SeriesColecoes()
    {
        return AcervoBase.ObterScriptSimplesComNomeEAuditoria(BibliograficoSeriesColecoes.SeriesColecoes(), "serie_colecao");
    }

    public static StringBuilder GerarScript()
    {
        AcervoBase.Append(Materiais());
        AcervoBase.Append(Idiomas());
        AcervoBase.Append(Autores());
        AcervoBase.Append(CoAutores());
        AcervoBase.Append(Editoras());
        AcervoBase.Append(Assuntos());
        AcervoBase.Append(SeriesColecoes());
        AcervoBase.Append(CoAutores());
        return AcervoBase.GerarScript();
    }
    
    
}